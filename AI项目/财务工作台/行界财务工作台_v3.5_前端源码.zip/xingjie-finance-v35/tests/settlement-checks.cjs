const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const mem=new Map(),context=vm.createContext({structuredClone,crypto:require('crypto').webcrypto,Date,Math,AbortSignal,console,navigator:{},window:{addEventListener(){}},document:{getElementById:()=>null},localStorage:{getItem:k=>mem.get(k)||null,setItem:(k,v)=>mem.set(k,v)},setTimeout,clearTimeout});
for(const file of ['app','trips','costs','cost-changes','payments','rules-v2','receipts','settlement'])vm.runInContext(fs.readFileSync('dist/'+file+'.js','utf8'),context);
const run=s=>vm.runInContext(s,context),j=s=>JSON.parse(run('JSON.stringify('+s+')'));let checks=0;function eq(s,val){assert.deepEqual(j(s),val,s);checks++;}function fails(s,re){assert.throws(()=>run(s),re);checks++;}
run(`db={trips:[{uid:'T1',id:'DZ-TEST',dep:'综合定制部',owner:'部门:综合定制部',sales:'示例销售员',operatorA:'江婧婕',operatorB:'示例操作员',category:'DZ'}],apps:[{id:'A1',tripUid:'T1',trip:'DZ-TEST',stage:3,amount:2500,currency:'CNY',paymentType:'业务付款',fee:'住宿',vendor:'酒店A',recipient:'hotel-account',creator:'操作 / 江婧婕',history:[],receiptSnapshot:{supplierName:'酒店A',card:'hotel-account'}}],balance:100000,logs:[],todos:[]};stMigrate(db);activeRole='财务 / 杜川黔';const input={version:0,requestKey:'REQ1',amount:1000,date:'2026-11-01',source:'bank',proof:{key:'fake',name:'fake.png'}};stExecute(db,'A1',input);`);
eq('db.balance',99000);eq('stPaymentState(db,db.apps[0])','部分付款');eq('stRemaining(db,db.apps[0])',150000);eq('rcPaid(db).length',1);eq('db.invoiceTasks.length',0);
fails(`stExecute(db,'A1',input)`,/已更新/);fails(`stExecute(db,'A1',{...input,version:1,requestKey:'REQ2',amount:1500.01})`,/超出/);eq('db.paymentReceipts.length',1);
run(`db.receiptAccounts.find(a=>a.id==='RC-BANK-2').balance=5000;stExecute(db,'A1',{...input,version:1,requestKey:'REQ2',amount:1500,source:'RC-BANK-2'});`);eq('stPaymentState(db,db.apps[0])','付款完成');eq('rcBalance(db,"RC-BANK-2")',3500);
// Wrong-payment refund restores original application limit, never destroys the original execution.
run(`db.receipts.push({id:'R-REF',version:1,status:'confirmed',type:'供应商退款',amount:500,allocations:[{ref:db.paymentReceipts[0].id,amount:500}],history:[]});db.balance+=500;stRefreshDirty(db);`);eq('stPaymentState(db,db.apps[0])','部分付款');eq('stRemaining(db,db.apps[0])',50000);eq('db.paymentReceipts.length',2);
run(`stExecute(db,'A1',{...input,version:2,requestKey:'REQ3',amount:500});`);eq('stNet(db,db.apps[0])',250000);eq('db.paymentReceipts.length',3);eq('db.balance',99000);
fails(`activeRole='销售 / 示例销售员';stExecute(db,'A1',{...input,version:3})`,/仅财务/);
// One reminder per tour/recipient/applicant; outgoing bank accounts do not split groups.
fails(`stComplete(db,'T1')`,/仅本团操作/);run(`activeRole='操作 / 江婧婕';stComplete(db,'T1')`);eq('db.invoiceTasks.length',1);eq('stInvoiceGroups(db,"T1").length',1);eq('stInvoiceGroups(db,"T1")[0].net',250000);eq('db.commissionSheets.length',0);
fails(`stComplete(db,'T1')`,/已经完结/);run('stRefreshInvoiceTasks(db)');eq('db.invoiceTasks.length',1);
run(`activeRole='财务 / 杜川黔';stInvoice(db,'T1',stInvoiceGroups(db,'T1')[0].key,2000,'虚构发票',{key:'i'});`);eq('stInvoiceGroups(db,"T1")[0].pending',50000);
// Real net receipts only; unallocated platform receipt and wallet recharge excluded.
run(`db.receipts.push({id:'R-IN',version:1,status:'confirmed',type:'客户团款',date:'2026-11-01',amount:10000,allocations:[{ref:'T1',amount:10000}],history:[]},{id:'R-PL',version:1,status:'confirmed',type:'平台结算款',amount:9000,allocations:[],history:[]},{id:'R-WALLET',version:1,status:'confirmed',type:'客户预存款',amount:3000,allocations:[],history:[]});`);eq('stFunds(db,"T1").profit',7500);
fails(`stGenerate(db,'T1','2026-11',false)`,/确认/);run(`const sheetId=stGenerate(db,'T1','2026-11',true);const s=()=>db.commissionSheets.find(s=>s.id===sheetId);`);eq('s().rows.map(r=>r.amount)',[750,360,270]);eq('stTotal(s().rows)',1380);
fails(`stGenerate(db,'T1','2026-11',true)`,/已有/);
// Reviewer edits, extras on top, reason required, one person multi-role aggregated by ID.
run(`activeRole='操作 / 江婧婕';const rows=structuredClone(s().rows);rows.push({id:'EXTRA',role:'协作奖励',employeeId:'EMP-004',amount:200,extra:true,inactive:false});`);
fails(`stEdit(db,sheetId,s().version,rows,'',true,true)`,/原因/);run(`stEdit(db,sheetId,s().version,rows,'增加协作奖励',true,true)`);eq('s().status','supervisor');eq('stTotal(s().rows)',1580);eq('s().snapshot.profit-stTotal(s().rows)',5920);
fails(`stApprove(db,sheetId,s().version,'approve','')`,/指定主管/);
run(`activeRole='销售 / 示例销售员';stObjection(db,sheetId,s().version,'请核对销售比例');`);eq('s().status','objection');
fails(`activeRole='主管 / 刘婷茹';stApprove(db,sheetId,s().version,'approve','')`,/指定主管|未解决/);
run(`activeRole='操作 / 江婧婕';stResolve(db,sheetId,s().version,'已沟通确认10%');stEdit(db,sheetId,s().version,s().rows,'',true,true);activeRole='主管 / 刘婷茹';stApprove(db,sheetId,s().version,'approve','');`);eq('s().status','approved');
// Financial changes after approval suspend exporting, preserve old snapshot, require reapproval.
run(`db.receipts.find(r=>r.id==='R-IN').allocations[0].amount=11000;db.receipts.find(r=>r.id==='R-IN').version++;stRefreshDirty(db);`);eq('s().status','dirty');eq('s().snapshot.profit',7500);
fails(`activeRole='财务 / 杜川黔';stPayroll(db,'2026-11','PAYROLL1')`,/没有可转/);
run(`activeRole='操作 / 江婧婕';stRecheck(db,sheetId,s().version,'到账补款重新核对');stEdit(db,sheetId,s().version,s().rows,'',true,true);activeRole='主管 / 刘婷茹';stApprove(db,sheetId,s().version,'approve','');activeRole='财务 / 杜川黔';const batchId=stPayroll(db,'2026-11','PAYROLL1');`);eq('s().status','transferred');eq('db.payrollBatches.length',1);eq('db.payrollBatches[0].lines.reduce((n,l)=>n+payCents(l.amount),0)',176400);
fails(`stPayroll(db,'2026-11','PAYROLL1')`,/已处理/);fails(`stPayroll(db,'2026-11','PAYROLL2')`,/没有可转/);
// Transferred snapshot immutable, refund generates negative differential next batch.
run(`db.receipts.find(r=>r.id==='R-IN').allocations[0].amount=10000;db.receipts.find(r=>r.id==='R-IN').version++;stRefreshDirty(db);`);eq('s().adjustmentNeeded',true);eq('s().snapshot.profit',8500);eq('db.payrollBatches[0].lines[0].amount',850);
run(`const adjId=stAdjustment(db,sheetId,s().version,'后续收款更正');const adj=()=>db.commissionSheets.find(s=>s.id===adjId);`);eq('adj().rows.map(r=>r.amount)',[-100,-48,-36,0]);eq('adj().month','2026-12');
run(`activeRole='操作 / 江婧婕';stEdit(db,adjId,adj().version,adj().rows,'差额核对无误',true,true);activeRole='主管 / 刘婷茹';stApprove(db,adjId,adj().version,'approve','');activeRole='财务 / 杜川黔';stPayroll(db,'2026-12','PAYROLL-ADJ');stRefreshDirty(db);`);eq('db.payrollBatches.length',2);eq('s().adjustmentNeeded',false);eq('stTotal(db.payrollBatches[1].lines)',-184);
// Zero/negative profit default allocations zero; explicit nonparticipation and extra fixed amount.
run(`const temp={snapshot:{profit:-10},rows:stDefaultRows(db,db.trips[0])};`);eq('stCalc(db,temp).map(r=>r.amount)',[0,0,0]);run('temp.snapshot.profit=100.01');eq('stCalc(db,temp).map(r=>r.amount)',[10,4.8,3.6]);run('temp.rows[0].inactive=true');eq('stCalc(db,temp).map(r=>r.amount)',[0,4.8,3.6]);
// Closing unpaid remainder doesn't create outgoing funds.
run(`db.apps.push({...structuredClone(db.apps[0]),id:'A2',stage:3,amount:100,amountCNY:100,executionVersion:0});const balanceBefore=db.balance;stClosePayment(db,'A2',0,'业务取消');`);eq('db.balance===balanceBefore',true);eq('stPaymentState(db,db.apps.at(-1))','已关闭');fails(`stExecute(db,'A2',{...input,amount:100})`,/关闭/);
console.log('Settlement checks passed:',checks);
