const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

const fields = new Map();
for (const name of ['tripCategory','foreignSource','tripPlatform','tripProduct','tripOrder','destScope','dest','destLabel','destNotice','date','tripPreview']) {
  const label = {hidden:false};
  fields.set(name,{value:'',dataset:{},closest:()=>label,set innerHTML(html){this.options=html;this.value='';}});
}
const context=vm.createContext({
  document:{getElementById:name=>fields.get(name)}, esc:String, activeRole:'操作 / 示例',
  db:{trips:[]}, PROVINCES:[{name:'河北',code:'HB'},{name:'湖北',code:'HB'}],
  COUNTRIES:[{name_zh:'日本',code:'JP'},{name_zh:'马来西亚',code:'MY'}]
});
vm.runInContext(fs.readFileSync('dist/trips.js','utf8'),context);
assert.equal(context.tripBaseCode('COTA','ZJ','2026-12-01','XC','MP'),'COTA-XC-MP-20261201');
assert.equal(context.tripBaseCode('COTA','ZJ','2026-12-01','XC',''),'');
assert.equal(context.tripBaseCode('COTA','','2026-12-01','XC','MP'),'');
assert.equal(context.tripBaseCode('RJ','XJ','2026-12-01'),'RJ-XJ-20261201');
assert.equal(context.tripBaseCode('AIRBNB','JP','2026-12-01'),'');
const base='DZ-HB-20261201';
assert.equal(context.nextTripCode(base,[]),base);
assert.equal(context.nextTripCode(base,[{id:base},{id:base+'-01'}]),base+'-02');
fields.get('destScope').value='domestic';
context.updateDestinations();
assert.match(fields.get('dest').options,/河北/);
fields.get('dest').value='河北';
assert.equal(context.chosenDestination().key,'domestic:河北');
fields.get('dest').value='湖北';
assert.equal(context.chosenDestination().key,'domestic:湖北');
assert.equal(context.chosenDestination().code,'HB');
fields.get('destScope').value='overseas';
context.updateDestinations();
assert.equal(fields.get('dest').value,'');
assert.match(fields.get('dest').options,/日本/);
fields.get('tripCategory').value='RJ';
context.updateTripCategory();
assert.equal(fields.get('foreignSource').required,true);
fields.get('foreignSource').value='MY';
fields.get('tripCategory').value='COTA';
context.updateTripCategory();
assert.equal(fields.get('foreignSource').value,'');
assert.equal(fields.get('foreignSource').disabled,true);
assert.equal(fields.get('tripPlatform').required,true);
assert.equal(fields.get('tripProduct').required,true);
const sameTrip=vm.runInContext("sameTrip",context);
assert.ok(sameTrip({trip:'旧团号',tripUid:'uid'},{trip:'新团号',tripUid:'uid'}));
assert.ok(sameTrip({trip:base},{trip:base,tripUid:'uid'}));
console.log('PASS: trip number formats, duplicate suffixes, destination and category linkage, historical references');
