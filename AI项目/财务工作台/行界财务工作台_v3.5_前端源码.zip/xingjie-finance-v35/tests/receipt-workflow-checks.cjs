const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const memory=new Map();const c=vm.createContext({structuredClone,crypto:require('crypto').webcrypto,Date,Math,AbortSignal,console,navigator:{},window:{addEventListener(){}},document:{getElementById:()=>null},localStorage:{getItem:k=>memory.get(k)||null,setItem:(k,v)=>memory.set(k,v)},setTimeout,clearTimeout});
for(const name of ['app','trips','costs','cost-changes','payments','rules-v2','receipts','settlement'])vm.runInContext(fs.readFileSync('dist/'+name+'.js','utf8'),c);
const run=s=>vm.runInContext(s,c),j=s=>JSON.parse(run('JSON.stringify('+s+')'));
run(`db={trips:[],apps:[],logs:[],todos:[],balance:100000};rcMigrate(db);activeRole='操作 / 江婧婕';const t={uid:'T1',id:'DZ-JP-20260910',category:'DZ',owner:'部门:综合定制部',dep:'综合定制部',departureDate:'2026-09-10',currency:'CNY'};db.trips.push(t,{...t,uid:'T2',id:'DZ-JP-20261010',departureDate:'2026-10-10'},{...t,uid:'T3',id:'VIA-RJT-JP-20260920',category:'OVERSEAS',platform:'VIA',product:'RJT'});const base={...rcNew(),accountId:'bank',date:'2026-11-15',amount:'30000',payer:'虚构客户',attachments:[{key:'fixture',name:'fake.png'}],allocations:[{ref:'T1',amount:20000,stage:'定金'},{ref:'T2',amount:10000,stage:'尾款'}]};`);
assert.deepEqual(j('rcValidate(base,db)'),[]);
run(`rcCommit(db,base,'submit')`);assert.equal(run('db.receipts[0].status'),'pending');assert.equal(run('db.balance'),100000);assert.equal(run('rcTripReceived(db,"T1")'),0);
assert.throws(()=>run(`rcAct(db,base.id,1,'confirm','')`),/仅财务/);
run(`activeRole='财务 / 杜川黔';rcAct(db,base.id,1,'confirm','')`);assert.equal(run('db.balance'),130000);assert.equal(run('rcTripReceived(db,"T1")'),20000);
assert.throws(()=>run(`rcAct(db,base.id,1,'confirm','')`),/记录已更新/);assert.throws(()=>run(`rcAct(db,base.id,2,'confirm','')`),/不能重复确认/);
run(`const correction={...structuredClone(db.receipts[0]),allocations:[{ref:'T1',amount:10000,stage:'定金'},{ref:'T2',amount:20000,stage:'尾款'}],changeReason:'更正分配'};rcCommit(db,correction,'correct')`);assert.equal(run('db.balance'),130000);assert.equal(run('rcTripReceived(db,"T1")'),10000);assert.equal(run('db.receipts[0].creator'),'操作 / 江婧婕');assert.equal(run('db.receipts[0].history.length'),3);
assert.throws(()=>run(`rcCommit(db,correction,'correct')`),/其他页面更新/);
run(`const platform={...rcNew(),type:'平台结算款',accountId:'bank',date:'2026-11-14',amount:'9500',payer:'Viator',platform:'VIA',product:'RJT',month:'2026-10',attachments:[{key:'platform',name:'fake.png'}],allocations:[]};rcCommit(db,platform,'submit')`);assert.equal(run('db.balance'),139500);assert.equal(run('rcAllocationState(db.receipts[0])'),'待分配');
run(`let pp={...structuredClone(db.receipts[0]),allocations:[{ref:'T3',amount:6000}],changeReason:'补分配'};rcCommit(db,pp,'correct')`);assert.equal(run('db.balance'),139500);assert.equal(run('rcTripReceived(db,"T3")'),6000);assert.equal(run('rcRemaining(db.receipts[0])'),3500);
assert.match(j(`rcValidate({...platform,allocations:[{ref:'T3',amount:10000}]},db,true)`).join(),/不能超过/);
assert.match(j(`rcValidate({...platform,attachments:[]},db,true)`).join(),/到账凭证/);
// Duplicate is a financial warning, allowed with finance explanation.
run(`const duplicate={...structuredClone(platform),id:'SK-DUP',reviewNote:''};`);assert.match(j('rcValidate(duplicate,db,true)').join(),/风险核查/);run(`duplicate.reviewNote='核对图片确认非重复'`);assert.deepEqual(j('rcValidate(duplicate,db,true)'),[]);
// Correct account and amount: deltas only, no double entry.
run(`let cp={...structuredClone(db.receipts.find(r=>r.id===base.id)),accountId:'RC-SUKHA',amount:31000,allocations:[{ref:'T1',amount:31000,stage:'定金'}],changeReason:'纠正账户和金额'};rcCommit(db,cp,'correct')`);assert.equal(run('db.balance'),109500);assert.equal(run('rcBalance(db,"RC-SUKHA")'),31000);
run(`rcAct(db,base.id,4,'cancel','误登记')`);assert.equal(run('rcBalance(db,"RC-SUKHA")'),0);assert.equal(run('rcTripReceived(db,"T1")'),0);
// Wallet funding consumed by offsets cannot be cancelled, and no bank entry at offset.
run(`db.customerWallets.push({id:'W1',name:'虚构钱包',customerId:'RC-CUSTOMER-DEMO',currency:'CNY',opening:0});const recharge={...rcNew(),type:'客户预存款',accountId:'bank',date:'2026-11-13',amount:'5000',payer:'充值客户',owner:'部门:综合定制部',customerId:'RC-CUSTOMER-DEMO',walletId:'W1',attachments:[{key:'w',name:'fake.png'}]};rcCommit(db,recharge,'submit')`);assert.equal(run('rcWalletBalance(db,"W1")'),5000);const bank=run('db.balance');
run(`const offsetId=rcOffset(db,'W1','T1',2000,'团款抵扣')`);assert.equal(run('rcWalletBalance(db,"W1")'),3000);assert.equal(run('db.balance'),bank);assert.equal(run('rcTripReceived(db,"T1")'),2000);
assert.throws(()=>run(`rcOffset(db,'W1','T1',4000,'余额不足')`),/余额不足/);assert.throws(()=>run(`rcAct(db,recharge.id,1,'cancel','取消充值')`),/已消费/);
run(`rcReverseOffset(db,offsetId,'撤销错误抵扣');rcAct(db,recharge.id,1,'cancel','误登记')`);assert.equal(run('rcWalletBalance(db,"W1")'),0);assert.equal(run('rcTripReceived(db,"T1")'),0);assert.equal(run('db.balance'),bank-5000);
// Supplier refunds filter only actually paid records; multiple refunds, no tour income/budget change.
run(`db.apps.push({id:'PAY1',stage:4,tripUid:'T1',vendor:'酒店',fee:'住宿'},{id:'PAY2',stage:1,tripUid:'T1',vendor:'酒店'});db.paymentReceipts.push({id:'P1',applicationId:'PAY1',amount:10000,source:'bank',date:'2026-09-01'},{id:'P2',applicationId:'PAY2',amount:100,source:'bank',date:'2026-09-01'});const refund={...rcNew(),type:'供应商退款',accountId:'bank',date:'2026-11-12',amount:2000,payer:'酒店',refundMode:'trip',refundTrip:'T1',refundReason:'取消',allocations:[{ref:'P1',amount:2000}],attachments:[{key:'refund',name:'fake.png'}]};rcCommit(db,refund,'submit');`);
assert.equal(run('rcRefundOptions(db,refund).length'),1);assert.equal(run('rcRefundTotal(db,"P1")'),2000);assert.equal(run('rcTripReceived(db,"T1")'),0);
run(`const refund2={...structuredClone(refund),id:'SK-R2',date:'2026-11-11',amount:3000,allocations:[{ref:'P1',amount:3000}]};rcCommit(db,refund2,'submit')`);assert.equal(run('rcRefundTotal(db,"P1")'),5000);assert.match(j(`rcValidate({...refund,id:'SK-OVER',amount:6000,allocations:[{ref:'P1',amount:6000}]},db,true)`).join(),/风险核查/);
// Internal transfer pairs existing paid record, no repeated outgoing debit.
run(`db.receiptAccounts.push({id:'RC-SAME',name:'同主体演示账户',company:COMPANY_OPTIONS[0],currency:'CNY',balance:0});db.apps.push({id:'INT1',stage:4,fee:'内部资金调拨',targetAccount:'RC-SAME'});db.paymentReceipts.push({id:'IP1',applicationId:'INT1',amount:100,source:'bank',internal:true,debitApplied:true,date:'2026-11-01'});const internal={...rcNew(),type:'资金往来收款',transferType:'公司内部资金调入',owner:'部门:总经办',accountId:'RC-SAME',sourceAccount:'bank',originalRef:'IP1',date:'2026-11-01',amount:100,payer:'本公司',counterparty:'本公司',attachments:[{key:'i',name:'i.png'}]};`);
const beforeInternal=run('db.balance');run(`rcCommit(db,internal,'submit')`);assert.equal(run('db.balance'),beforeInternal);assert.equal(run('rcBalance(db,"RC-SAME")'),100);assert.match(j(`rcValidate({...internal,id:'SK-I2'},db,true)`).join(),/重复登记/);
// Return/re-submit and ownership.
run(`activeRole='操作 / 江婧婕';const returned={...structuredClone(base),id:'SK-RETURN',version:0,date:'2026-11-10'};rcCommit(db,returned,'submit');activeRole='财务 / 杜川黔';rcAct(db,returned.id,1,'return','请核对图片');activeRole='操作 / 江婧婕';let resub=structuredClone(db.receipts.find(r=>r.id===returned.id));rcCommit(db,resub,'submit')`);assert.equal(run(`db.receipts.find(r=>r.id==='SK-RETURN').status`),'pending');

// Simplified customer receipts do not require business filter or proxy fields.
assert.equal(run('rcTrips(db,{type:"客户团款",business:"DZ"}).length'),3);
assert.deepEqual(j(`rcValidate({...base,business:'',proxy:true,proxyNote:''},db)`),[]);
const balancesBeforeWallet=run('db.balance');
assert.throws(()=>run(`rcEnsureWallet(db,'','')`),/选择已有客户/);
run(`const ew=rcEnsureWallet(db,'','虚构新钱包');const reused=rcEnsureWallet(db,ew.customerId,'');`);
assert.equal(run('ew.walletId===reused.walletId'),true);assert.equal(run('reused.reused'),true);
assert.equal(run('rcWalletBalance(db,ew.walletId)'),0);assert.equal(run('db.balance'),balancesBeforeWallet);

console.log('PASS: multi-tour receipts, role confirmation, pending allocation, account deltas, duplicate/stale checks, wallet funding/reversal, supplier refund, internal pairing, return/resubmit');
