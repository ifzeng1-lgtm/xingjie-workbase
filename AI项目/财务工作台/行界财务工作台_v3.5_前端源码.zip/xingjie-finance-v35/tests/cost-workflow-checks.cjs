const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const memory=new Map(),fields=new Map();let toasts=[];
const c=vm.createContext({structuredClone,crypto:require('crypto').webcrypto,Date,Math,AbortSignal,console,navigator:{},window:{addEventListener(){}},document:{getElementById:id=>fields.get(id)||null},localStorage:{getItem:k=>memory.get(k)||null,setItem:(k,v)=>memory.set(k,v)},setTimeout,clearTimeout,confirm:()=>true});
for(const file of ['app.js','trips.js','costs.js','cost-changes.js'])vm.runInContext(fs.readFileSync('dist/'+file,'utf8'),c);
const run=s=>vm.runInContext(s,c),j=s=>JSON.parse(run('JSON.stringify('+s+')'));
run('render=()=>{};renderCostRows=()=>{};toast=message=>console.log("NOTICE:",message);diagnostic=()=>{};');
run(`db={trips:[{uid:'T',id:'DZ-XJ-test',dep:'综合定制部',costVersion:1,costConfirmed:true,budget:18000,file:'cost.xlsx',costItems:[{id:'hotel',name:'酒店A',category:'住宿',amount:10000,include:true},{id:'car',name:'包车',category:'交通',amount:8000,include:true}]}],costChanges:[],apps:[],logs:[],todos:[],balance:100000};costMigrate(db);localStorage.setItem(KEY,JSON.stringify(db));selectedCostTrip='T';`);
assert.equal(j('costDiff(db.trips[0].costItems,[...db.trips[0].costItems].reverse())').length,0,'row reorder is not a diff');
assert.equal(run('costReviewer(db.trips[0])'),'主管 / 刘婷茹');
assert.equal(run('costReviewer({dep:"新媒体"})'),null,'unknown reviewer is not guessed');
async function main(){
 run(`startCostChange();costDraft.items[0].amount=12000;costDraft.confirmed=true;costEditor.reason='酒店价格调整';`);
 await run('saveCostChange(true)');
 assert.equal(run('db.costChanges[0].status'),'pending');assert.equal(run('db.trips[0].costItems[0].amount'),10000,'pending keeps effective version');
 run(`const savedPending=db.costChanges[0].id;startCostChange();`);assert.equal(run('costEditor'),null,'second pending blocked');
 await run(`costMutate(data=>{data.apps.push({id:'p1',tripUid:'T',trip:'DZ-XJ-test',costId:'hotel',amount:8000,stage:4},{id:'p2',tripUid:'T',trip:'DZ-XJ-test',costId:'hotel',amount:2000,stage:3})})`);
 let risk=j(`checkPayment({tripUid:'T',costId:'hotel',amount:1000})`);assert.equal(risk.risk,true);assert.equal(risk.used,10000);assert.equal(risk.limit,10000);
 run(`db.costChanges[0].items.push({id:'new-ticket',name:'门票',category:'门票',amount:3000});`);assert.equal(run(`checkPayment({tripUid:'T',costId:'new-ticket',amount:500}).risk`),true,'pending new line warns');
 // Re-read ensures the in-memory pending modification above is never silently persisted.
 run(`db=costReadLatest();activeRole='主管 / 黄庆'`);fields.set('costReviewOpinion',{value:''});fields.set('costReviewRisk',{value:'[]'});
 await run(`reviewCostChange('approved')`);assert.equal(run('db.costChanges[0].status'),'pending','wrong supervisor blocked');
 run(`activeRole='主管 / 刘婷茹'`);await run(`reviewCostChange('approved')`);
 assert.equal(run('db.trips[0].costVersion'),2);assert.equal(run('db.trips[0].costItems[0].amount'),12000);assert.equal(run('db.trips[0].costVersions[0].items[0].amount'),10000,'old version retained');assert.equal(run('db.apps[0].stage'),4,'cost approval never changes payment approval');
 // Lowering / deleting paid items exposes risk and rechecks live occupancy at approve time.
 run(`activeRole='操作 / 江婧婕';startCostChange();costDraft.items[0].amount=6000;costDraft.confirmed=true;costEditor.reason='减房';`);await run('saveCostChange(true)');
 run(`activeRole='主管 / 刘婷茹'`);fields.set('costReviewRisk',{value:run('costRiskSignature(changeRisks(db,db.costChanges[1]))')});fields.set('costReviewAck',{checked:true});
 await run(`costMutate(data=>data.apps.push({id:'p3',tripUid:'T',costId:'hotel',amount:1000,stage:0}))`);await run(`reviewCostChange('approved')`);assert.equal(run('db.trips[0].costVersion'),2,'stale risk prevents approval');
 fields.get('costReviewRisk').value=run('costRiskSignature(changeRisks(db,db.costChanges[1]))');await run(`reviewCostChange('returned')`); // reason required
 assert.equal(run('db.costChanges[1].status'),'pending');fields.get('costReviewOpinion').value='核对费用';await run(`reviewCostChange('returned')`);assert.equal(run('db.costChanges[1].status'),'returned');assert.equal(run('db.trips[0].costVersion'),2);
 run(`activeRole='操作 / 江婧婕';startCostChange(db.costChanges[1].id);costDraft.items[0].amount=0;costDraft.confirmed=true;`);await run('saveCostChange(true)');assert.equal(run('db.costChanges[1].status'),'pending');assert.equal(run('db.costChanges[1].items[0].amount'),0,'zero allowed');
 await run('withdrawCostChange()');assert.equal(run('db.costChanges[1].status'),'withdrawn');
 // Cross-attempt occupancy excludes self, rejected and withdrawn; payment counts once by state.
 run(`db.apps[1].special='已撤回';db.apps[2].special='已拒绝';`);assert.equal(run(`checkPayment({tripUid:'T',costId:'hotel',amount:4000}).risk`),false);
 assert.equal(run(`checkPayment({id:'p1',tripUid:'T',costId:'hotel',amount:12000}).risk`),false);
 run(`activeRole='操作 / 江婧婕';db=costReadLatest();costEditor={tripRef:'T',baseVersion:2,mode:'upload'};costDraft.items=[{name:'酒店A',category:'住宿',amount:13000,include:true}];ensureChangeMatches();`);
 assert.equal(run('costDraft.items[0].originId'),'hotel');assert.equal(run('costDraft.items[0].matchConfirmed'),true,'unique identity matches automatically despite amount change');
 assert.equal(run('mappingError()'),'');run(`costDraft.items[0].matchConfirmed=true;costDraft.items.push({...costDraft.items[0]});`);assert.match(run('mappingError()'),/重复/);
 // Changed upload: unchanged auto-passes, only actual differences are reviewed.
 run(`costDraft.items=[{name:'包车',category:'交通',amount:8000,include:true},{name:'酒店A',category:'住宿',amount:13000,include:true},{name:'新景区',category:'门票',amount:500,include:true}];ensureChangeMatches();`);
 assert.equal(run('mappingError()'),'');
 assert.equal(run('costDraft.items[0].originId'),'car','reordered unchanged item matches original ID');
 assert.equal(run('costDraft.items[1].originId'),'hotel');assert.equal(run('costDraft.items[2].originId'),'new');
 assert.equal(run('costDiff(db.trips[0].costItems,changeProposedItems()).length'),2);
 assert.ok(!run('changeMappingHtml()').includes('员工确认'),'no per-line confirmation checkbox');
 // Repeated ambiguous names do not get guessed.
 run(`db.trips[0].costVersions[1].items=[{id:'a',name:'同名酒店',category:'住宿',amount:100},{id:'b',name:'同名酒店',category:'住宿',amount:100}];costDraft.items=[{name:'同名酒店',category:'住宿',amount:100,include:true}];ensureChangeMatches();`);
 assert.match(run('mappingError()'),/无法确定/);
 // Both exits discard unconfirmed edits without dialogs or new persisted applications.
 run(`confirm=()=>{throw Error('exit must not prompt')};page='成本变更';`);
 const before=memory.get('xingjie-demo-v1');
 run('leaveCostEditor()');assert.equal(run('costEditor'),null);assert.equal(run('costDraft.items.length'),0);assert.equal(memory.get('xingjie-demo-v1'),before);
 run(`costEditor={tripRef:'T',baseVersion:2,mode:'upload'};costDraft.items=[{name:'未完成',amount:''}];go('团档案');`);
 assert.equal(run('page'),'团档案');assert.equal(run('costEditor'),null);assert.equal(run('costDraft.items.length'),0);assert.equal(memory.get('xingjie-demo-v1'),before);
 console.log('PASS: cost workflow (effective versions, single pending, matching, zero, permissions, return, withdrawal, risks, stale approval and ledger occupation)');
}
main().catch(e=>{console.error(e);process.exitCode=1});
