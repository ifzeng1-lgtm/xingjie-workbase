const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const memory=new Map(),fields=new Map();
const c=vm.createContext({structuredClone,crypto:require('crypto').webcrypto,Date,Math,AbortSignal,console,navigator:{},window:{addEventListener(){}},document:{getElementById:id=>fields.get(id)||null},localStorage:{getItem:k=>memory.get(k)||null,setItem:(k,v)=>memory.set(k,v)},setTimeout,clearTimeout});
for(const name of ['app','trips','costs','cost-changes','payments','rules-v2','receipts','settlement'])vm.runInContext(fs.readFileSync('dist/'+name+'.js','utf8'),c);
const run=s=>vm.runInContext(s,c),j=s=>JSON.parse(run('JSON.stringify('+s+')'));
run(`db={trips:[],apps:[],logs:[],todos:[],costChanges:[],balance:100000};payMigrate(db);render=()=>{};toast=()=>{};diagnostic=()=>{};`);
run(`const t={uid:'T',id:'VIA-RJT-JP-20260920',archiveKind:'single',category:'OVERSEAS',owner:'部门:电商部',dep:'电商部',platform:'VIA',product:'RJT',departureDate:'2026-09-20',externalOrder:'VIA-001',costConfirmed:true,costVersion:1,costItems:[{id:'cost',category:'交通',name:'包车',amount:1000}],budget:1000};db.trips.push(t);const d={...payNew(),type:'业务付款',business:'OVERSEAS',owner:t.owner,platform:t.platform,product:t.product,tripRef:'T',fee:'交通',note:'测试车款',amount:200,currency:'CNY',rate:1,channel:'公账收款',payee:'虚构测试公司',bank:'测试银行',card:'0000000000000000',demoBasis:true};`);
assert.deepEqual(j('paymentValidate(d,db)'),[],'overseas payment accepts single archived tour without settlement month or due date');
assert.equal(run('d.company'),'','company is optional');
assert.equal(run('Object.hasOwn(payNew(),"due")'),false);
run('db.trips[0].costConfirmed=false');assert.match(j('paymentValidate(d,db)').join(),/确认预算成本/);run('db.trips[0].costConfirmed=true');
run('db.trips[0].archiveKind="monthly"');assert.match(j('paymentValidate(d,db)').join(),/独立团档/);run('db.trips[0].archiveKind="single"');
assert.equal(run('tripBaseCode("OVERSEAS","JP","2026-09-20","VIA","RJT")'),'VIA-RJT-JP-20260920');
run(`const admin={...d,type:'管销付款',fee:'管理费用|市内交通费',period:'2026-09',tripRef:'',supplierId:'manual',supplierName:'未入库测试对象'};`);
assert.deepEqual(j('paymentValidate(admin,db)'),[],'unlisted supplier is warning only and no tour is required');
assert.match(run('supplierFlag(admin)'),/未入库/);
assert.match(j(`paymentValidate({...admin,bank:''},db)`).join(),/银行名称/);
assert.match(j(`paymentValidate({...admin,channel:'二维码收款',qrName:''},db)`).join(),/二维码图片/);
assert.deepEqual(j(`paymentValidate({...admin,channel:'二维码收款',qrName:'test.png',bank:'',card:''},db)`),[],'QR branch does not require bank fields');
assert.match(j(`paymentValidate({...admin,company:'不存在主体'},db)`).join(),/公司主体/);
// Stable archive identity across departure and settlement months.
run(`db.trips.push({...t,uid:'T2',id:'VIA-RJT-JP-20261002',departureDate:'2026-10-02',externalOrder:'VIA-002'});const s={id:'',version:0,owner:t.owner,platform:'VIA',product:'RJT',month:'2026-10',reference:'DEMO-SET-001',receivedDate:'2026-11-01',currency:'CNY',net:'900',deductions:'100',reason:'测试佣金100',selected:{T:'600',T2:'400'}};`);
assert.equal(run('settlementCandidate(db,s).length'),2,'candidates include September and October departures');
assert.deepEqual(j('settlementValidate(s,db,true)'),[]);assert.equal(run('settlementTotals(s).difference'),0);
assert.match(j(`settlementValidate({...s,selected:{T:'500'}},db,true)`).join(),/归属金额减扣款/);
run(`db.settlements.push({...s,id:'S1',status:'confirmed',version:1,allocations:[{tripRef:'T',amount:600},{tripRef:'T2',amount:400}]});`);
assert.match(j('settlementValidate(s,db,true)').join(),/重复计入/);
run('db.settlements[0].status="locked"');assert.match(j(`settlementValidate({...s,id:'S1',version:1},db,true)`).join(),/已锁定/);
run('db.settlements[0].status="confirmed"');assert.match(j(`settlementValidate({...s,id:'S1',version:0},db,true)`).join(),/其他页面更新/);
// Saving draft/confirming does not create a tour, payment or bank entry.
async function main(){
run(`db.settlements=[];localStorage.setItem(KEY,JSON.stringify(db));activeRole='财务 / 杜川黔';settlementDraft=structuredClone(s);`);
await run('saveSettlement({preventDefault(){}},true)');assert.equal(run('db.settlements.length'),1);assert.equal(run('db.settlements[0].status'),'confirmed');assert.equal(run('db.trips.length'),2);assert.equal(run('db.apps.length'),0);assert.equal(run('db.balance'),100000);
run('settlementDraft=structuredClone(s)');await run('saveSettlement({preventDefault(){}},true)');assert.equal(run('db.settlements.length'),1);
await run('lockSettlement(db.settlements[0].id)');assert.equal(run('db.settlements[0].status'),'locked');
console.log('PASS: optional company/no due date, prior budget archive, overseas per-order payment, supplier and receipt branches, monthly cross-date reconciliation, duplicate/version/lock checks');
}
main().catch(e=>{console.error(e);process.exitCode=1});
