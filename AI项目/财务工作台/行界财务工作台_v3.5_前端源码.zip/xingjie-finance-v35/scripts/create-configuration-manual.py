from pathlib import Path
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
root=Path(__file__).resolve().parents[1];out=root.parent/'outputs';d=Document();sec=d.sections[0];sec.page_width=Inches(8.5);sec.page_height=Inches(11);sec.top_margin=sec.bottom_margin=Inches(.7);sec.left_margin=sec.right_margin=Inches(.75)
for name in ['Normal','Title','Heading 1','Heading 2']:
 s=d.styles[name];s.font.name='Noto Sans CJK SC';s._element.rPr.rFonts.set(qn('w:eastAsia'),'Noto Sans CJK SC');s.font.color.rgb=RGBColor(0,0,0)
d.styles['Normal'].font.size=Pt(10.5);d.styles['Normal'].paragraph_format.space_after=Pt(6);d.styles['Normal'].paragraph_format.line_spacing=1.08
d.styles['Title'].font.size=Pt(24);d.styles['Heading 1'].font.size=Pt(17);d.styles['Heading 2'].font.size=Pt(13)
md=[]
def h(t,level=1):d.add_heading(t,level);md.append('\n'+'#'*(level+1)+' '+t+'\n')
def p(t):d.add_paragraph(t);md.append(t+'\n')
def table(head,rows,widths=None):
 t=d.add_table(rows=1, cols=len(head));t.autofit=False
 if widths:
  for col,w in zip(t.columns,widths):col.width=Inches(w)
 for i,x in enumerate(head):t.rows[0].cells[i].text=x
 trpr=t.rows[0]._tr.get_or_add_trPr();repeat=OxmlElement('w:tblHeader');trpr.append(repeat)
 for row in rows:
  cells=t.add_row().cells
  for i,x in enumerate(row):cells[i].text=str(x)
 for ri,row in enumerate(t.rows):
  for i,c in enumerate(row.cells):
   if widths:c.width=Inches(widths[i])
   tcPr=c._tc.get_or_add_tcPr();b=OxmlElement('w:tcBorders')
   for edge in ['top','left','bottom','right']:
    el=OxmlElement('w:'+edge);el.set(qn('w:val'),'single');el.set(qn('w:sz'),'4');el.set(qn('w:color'),'D9D9D9');b.append(el)
   tcPr.append(b);shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'E7EEF2' if ri==0 else ('F7F9FA' if ri%2==0 else 'FFFFFF'));tcPr.append(shade)
   margins=OxmlElement('w:tcMar')
   for edge in ['top','left','bottom','right']:
    e=OxmlElement('w:'+edge);e.set(qn('w:w'),'95');e.set(qn('w:type'),'dxa');margins.append(e)
   tcPr.append(margins)
   for par in c.paragraphs:
    par.paragraph_format.space_after=Pt(3)
    for r in par.runs:r.font.size=Pt(10.5);r.bold=ri==0
 d.add_paragraph('');md.append('| '+' | '.join(head)+' |\n| '+' | '.join(['---']*len(head))+' |\n'+'\n'.join('| '+' | '.join(map(str,row))+' |' for row in rows)+'\n')
def page():d.add_page_break()
d.add_paragraph('行界财务工作台配置员操作手册','Title');md.append('# 行界财务工作台配置员操作手册\n');p('适用人员：配置员、负责确认配置的财务和总经理。版本日期：2026年11月21日。')
p('本手册说明基础资料、核算规则、审批流程和日志的维护入口。配置员负责整理并提交资料，需确认的修改在指定人员确认后生效。')
h('导航与常用入口')
table(['一级导航','二级入口'],[['我的工作台','维护摘要、快捷入口、待办摘要、最近配置变更'],['基础配置','组织与人员、业务字典、往来单位'],['核算与流程配置','公司账户、核算规则、提成规则、审批流程'],['操作日志','配置记录、业务操作记录、异常记录']],[1.5,5.3])
h('首页怎么用',2);p('顶部查看待维护、待确认配置和异常记录。四个快捷按钮进入组织与人员、业务字典、公司账户、审批流程。右侧最多显示五条待办，下方显示最近五条配置变更。')
h('维护与确认分工',2);p('配置员维护基础资料并发起变更。公司账户、期初余额、核算汇率、费用分摊及跨月归集由财务确认，总经理也有确认权。涉及核算口径的字典和提成规则提交财务或总经理确认；审批流程及临时代办由总经理确认。')
page();h('基础配置')
h('组织与人员',2);table(['标签','填写内容'],[['部门','部门名称、主管、启用状态'],['项目','项目名称、所属部门、负责人、启用状态'],['员工','姓名、所属部门、负责项目、角色、启用状态']],[1.2,5.6]);p('进入基础配置中的组织与人员，选择标签，搜索已有资料后点击编辑；新增资料点击新增。员工可以具有多个角色。负责项目可填写多个，使用逗号分隔。修改完成后填写变更原因再保存。')
h('业务字典',2);table(['标签','填写内容'],[['费用分类','名称、编码、费用大类、排序'],['平台','名称、编码、国内或海外'],['业务项目','名称、编码、适用平台'],['目的地','名称、国家或地区、省份、城市、团号编码'],['公司主体','主体名称、启用状态']],[1.2,5.6]);p('组织项目指管理归属，业务项目指产品或业务内容。编码用于区分资料，同类编码不能重复。字典修改提交确认后，原有效资料继续使用；确认生效后再供新业务使用。')
h('停用已有资料',2);p('点击停用后核对编辑表单，填写交接或停用原因，再保存或提交确认。停用不删除历史单据。已有付款收款资料保留提交时的快照。')
page();h('往来单位与公司账户')
h('供应商和收款信息',2);p('先在往来单位的供应商标签维护名称、开票单位、联系人和联系方式，再到收款信息标签选择供应商。一个供应商可维护多组收款资料，并设置默认项。')
table(['收款方式','必填资料'],[['公账收款或私账收款','收款人或单位、银行名称、银行卡号'],['二维码收款','收款人或单位、二维码图片']],[2.0,4.8]);p('二维码支持上传图片；请核对图片及收款人是否一致。修改供应商资料不会改写已提交付款申请中的收款信息。')
h('客户与预存钱包',2);p('先维护客户，再新增该客户的钱包，填写钱包名称、客户和币种。钱包创建不产生到账。余额只读，充值、抵扣和退款在对应业务流程中处理，配置员不能直接修改钱包余额。')
h('公司账户',2);p('入口：核算与流程配置中的公司账户。查看账户及当前余额，填写账户编号、账户名称、所属公司主体、期初日期及期初余额，填写依据后提交确认。修改已有账户时必须使用原账户编号。')
p('当前原型的账户及钱包资金执行采用人民币。当前余额由期初和实际收付款更新，不能当作普通资料直接编辑。期初变更须由财务核对账户流水与银行余额。')
page();h('核算规则与提成规则')
h('核算汇率',2);p('入口：核算与流程配置中的核算规则，切换核算汇率。选择外币、适用月份，填写财务手工维护的核算汇率和依据，提交财务或总经理确认。不自动抓取汇率；历史单据保留核定时的汇率快照。')
h('公共费用分摊',2);p('在核算规则中选择公共费用分摊，填写费用适用范围、起止月份及各承担部门比例。比例合计必须为100%。涉及历史月份需勾选历史调整并填写原因。电商部国内与海外业务不另设二次管销分摊。')
h('跨月分摊',2);p('选择跨月分摊，关联原非团费用付款单，填写费用名称、类别、承担部门、总金额和覆盖月份，提交财务确认。系统按覆盖月份分配金额，末月吸收分位尾差；相同原付款不能重复归集。')
p('员工基础工资及单位承担的五险一金归员工所属部门，按对应成本月份确认。团内提成在团内扣减。经营费用归集不产生新的现金收付。')
h('提成规则',2);table(['内容','默认设置'],[['销售','10%'],['操作 A','4.8%'],['操作 B','3.6%'],['核对人员','默认操作 A，可在具体团中调整']],[2.0,4.8]);p('填写规则名称、起始月份及比例，提交财务或总经理确认。主管仍可在具体团提成单中调整人员、比例或金额，另加固定奖励。默认规则变更不覆盖已经生成的提成单。')
page();h('审批流程与操作日志')
h('修改审批流程',2);p('入口：核算与流程配置中的审批流程。搜索部门及事项，点击原流程的编辑，调整审核人员；付款流程可新增、删除和调整节点顺序。成本变更和提成采用主管节点，经营核对采用主管、财务节点，可调整对应人员。')
p('核对事项类型、部门、项目和业务类型，再查看流程预览，填写原因并提交。总经理在首页的待确认配置中查看前后差异，填写意见后确认或退回。审批中的申请保留原流程版本，新提交申请使用生效配置。')
h('设置临时代办',2);p('在审批流程页切换临时代办，填写原审核人、代办人及起止日期，提交总经理确认。到期后恢复原审核人。代办人须具备对应审核角色。')
h('查询操作日志',2);table(['标签','查看内容'],[['配置记录','修改人、时间、变更原因、修改前后内容及确认结果'],['业务操作记录','建团、申请、审核、经营核定等业务轨迹'],['异常记录','失败环节、错误详情和错误编号']],[1.6,5.2]);p('选择标签后，按日期、人员、状态或类型，以及团号、单号或错误编号查询，点击记录展开详情。日志自动生成，仅可查询。查询无记录不代表操作成功。')
h('发现保存失败时',2);p('记下操作时间、团号或单号，进入异常记录查询错误编号和失败原因。先核对必填项和当前角色，再重试；仍失败时把错误编号交给维护人员。机器人查询入口在正式接入后提供。')
p('原型说明：当前页面用于流程评审，数据保存在当前浏览器；角色切换不是真实登录。付款支持配置流程快照走查；其他事项的完整流程版本路由与真实权限须在正式后台接入时联调验收。')
footer=sec.footer.paragraphs[0];footer.text='行界财务工作台  配置员操作手册';footer.runs[0].font.size=Pt(9)
for element in d.styles.element.iter():
 for child in list(element):
  if child.tag==qn('w:pBdr'):element.remove(child)
f=out/'行界财务工作台_配置员操作手册_20261121.docx';d.save(f);(root/'docs/配置员操作手册_20261121.md').write_text('\n'.join(md));print(f)
