"""Build offline HTML and source/deployment ZIPs without changing runtime data."""
from pathlib import Path
import argparse,base64,hashlib,re,shutil,zipfile
root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,default=root.parent/'outputs'/'prototype-v36');args=parser.parse_args()
out=args.out.resolve();out.mkdir(parents=True,exist_ok=True);dist=root/'dist'
# Hash all local JS/CSS references so replacing static files does not keep an old module from cache.
index=dist/'index.html';s=index.read_text()
def version(m):
 path=dist/m[2];assert path.is_file(),path
 return m[1]+m[2]+'?v='+hashlib.sha256(path.read_bytes()).hexdigest()[:12]+m[3]
s=re.sub(r'((?:src|href)=")([^"?]+\.(?:js|css))(?:\?[^" ]*)?(")',version,s);index.write_text(s)
xlsx='data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,'+base64.b64encode((dist/'example-cost.xlsx').read_bytes()).decode()
logo='data:image/png;base64,'+base64.b64encode((dist/'assets/xingjie-logo.png').read_bytes()).decode()
def script(m):
 name=m[1].split('?')[0]
 source=(dist/name).read_text().replace("fetch('example-cost.xlsx')","fetch('"+xlsx+"')").replace('href="example-cost.xlsx"','href="'+xlsx+'"').replace('assets/xingjie-logo.png',logo)
 # Inline classic scripts preserve order without separately loading/decoding data URLs.
 source=re.sub(r'</script',lambda m:'<\\/script',source,flags=re.I)
 return '<script data-module="'+name+'">'+source+'</script>'
html=re.sub(r'<link rel="stylesheet" href="([^"]+)">',lambda m:'<style>'+(dist/m[1].split('?')[0]).read_text()+'</style>',s)
html=re.sub(r'<script src="([^"]+)"></script>',script,html).replace('href="example-cost.xlsx"','href="'+xlsx+'"').replace('assets/xingjie-logo.png',logo)
assert not re.search(r'<script[^>]+src="(?!data:)|<link[^>]+rel="stylesheet"',html)
offline=out/'行界财务工作台_v3.6_离线原型.html';offline.write_text(html)
stage=out/'source';shutil.rmtree(stage,ignore_errors=True);stage.mkdir()
for name in ['dist','tests','scripts','docs']:shutil.copytree(root/name,stage/name,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
shutil.copy2(root/'README.md',stage/'README.md')
# Copy the deployable entry and startup guard verbatim, including critical startup CSS.
def zip_tree(path,target,prefix=''):
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
  for f in sorted(path.rglob('*')):
   if f.is_file():z.write(f,(Path(prefix)/f.relative_to(path)).as_posix())
zip_tree(stage,out/'行界财务工作台_v3.6_前端源码.zip','xingjie-finance-v36')
zip_tree(stage/'dist',out/'行界财务工作台_v3.6_部署静态文件.zip')
print('\n'.join(str(out/f) for f in ['行界财务工作台_v3.6_离线原型.html','行界财务工作台_v3.6_前端源码.zip','行界财务工作台_v3.6_部署静态文件.zip']))
