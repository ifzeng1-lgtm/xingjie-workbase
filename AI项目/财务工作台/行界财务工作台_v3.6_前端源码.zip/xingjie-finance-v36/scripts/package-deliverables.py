"""Build offline HTML and source/deployment ZIPs without changing runtime data."""
from pathlib import Path
import argparse,base64,hashlib,re,shutil,zipfile
root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,default=root.parent/'outputs'/'prototype-v36');args=parser.parse_args()
out=args.out.resolve();out.mkdir(parents=True,exist_ok=True);dist=root/'dist'
# Hash all local JS/CSS references so replacing static files does not keep an old module from cache.
index=dist/'index.html';s=index.read_text()
def version(m):
 path=dist/m[2];assert path.is_file(),path
 return m[1]+m[2]+'?v='+hashlib.sha256(path.read_bytes()).hexdigest()[:12]+m[3]
s=re.sub(r'((?:src|href)=")([^"?]+\.(?:js|css))(?:\?[^" ]*)?(")',version,s);index.write_text(s)
xlsx='data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,'+base64.b64encode((dist/'example-cost.xlsx').read_bytes()).decode()
logo='data:image/png;base64,'+base64.b64encode((dist/'assets/xingjie-logo.png').read_bytes()).decode()
def script(m):
 source=(dist/m[1].split('?')[0]).read_text().replace("fetch('example-cost.xlsx')","fetch('"+xlsx+"')").replace('href="example-cost.xlsx"','href="'+xlsx+'"').replace('assets/xingjie-logo.png',logo)
 return '<script src="data:text/javascript;base64,'+base64.b64encode(source.encode()).decode()+'"></script>'
html=re.sub(r'<link rel="stylesheet" href="([^"]+)">',lambda m:'<style>'+(dist/m[1].split('?')[0]).read_text()+'</style>',s)
html=re.sub(r'<script src="([^"]+)"></script>',script,html).replace('href="example-cost.xlsx"','href="'+xlsx+'"').replace('assets/xingjie-logo.png',logo)
assert not re.search(r'<script[^>]+src="(?!data:)|<link[^>]+rel="stylesheet"',html)
offline=out/'行界财务工作台_v3.6_离线原型.html';offline.write_text(html)
stage=out/'source';shutil.rmtree(stage,ignore_errors=True);stage.mkdir()
for name in ['dist','tests','scripts','docs']:shutil.copytree(root/name,stage/name,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
shutil.copy2(root/'README.md',stage/'README.md')
# Hand off separate HTML, CSS, JavaScript while retaining the buildless entry point.
p=stage/'dist/index.html';source=p.read_text();styles=[]
source=re.sub(r'<style>(.*?)</style>',lambda m:styles.append(m[1]) or '<link rel="stylesheet" href="styles.css">',source,flags=re.S)
if styles:(stage/'dist/styles.css').write_text('\n'.join(styles))
source=source.replace('<script>render();</script>','<script src="init.js"></script>');(stage/'dist/init.js').write_text('render();\n');p.write_text(source)
def zip_tree(path,target,prefix=''):
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
  for f in sorted(path.rglob('*')):
   if f.is_file():z.write(f,(Path(prefix)/f.relative_to(path)).as_posix())
zip_tree(stage,out/'行界财务工作台_v3.6_前端源码.zip','xingjie-finance-v36')
zip_tree(stage/'dist',out/'行界财务工作台_v3.6_部署静态文件.zip')
print('\n'.join(str(out/f) for f in ['行界财务工作台_v3.6_离线原型.html','行界财务工作台_v3.6_前端源码.zip','行界财务工作台_v3.6_部署静态文件.zip']))
