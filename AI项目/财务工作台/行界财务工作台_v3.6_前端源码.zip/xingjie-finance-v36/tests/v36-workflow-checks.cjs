const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const memory=new Map(),fields=new Map();
const ctx=vm.createContext({structuredClone,crypto:require('node:crypto').webcrypto,Date,Math,console,AbortSignal,navigator:{},window:{addEventListener(){}},document:{getElementById:id=>fields.get(id)||null},localStorage:{getItem:k=>memory.get(k)||null,setItem:(k,v)=>memory.set(k,v)},setTimeout,clearTimeout});
const order=[...fs.readFileSync('dist/index.html','utf8').matchAll(/<script src="([^"?]+)(?:\?[^"]*)?">/g)].map(m=>m[1]).filter(f=>!['init.js','searchable-select.js','diagnostics.js','visual.js'].includes(f));
for(const f of order)vm.runInContext(fs.readFileSync('dist/'+f,'utf8'),ctx,{filename:f});
const run=s=>vm.runInContext(s,ctx),json=s=>JSON.parse(run('JSON.stringify('+s+')'));let count=0;
const eq=(s,v)=>{assert.deepEqual(json(s),v,s);count++;},throws=(s,re)=>{assert.throws(()=>run(s),re);count++;},match=(s,re)=>{assert.match(run(s),re);count++;};
run(`db={trips:[],apps:[],logs:[],todos:[],balance:100000};v36Init(db);cfInit(db);render=()=>{};toast=()=>{};diagnostic=()=>{};activeRole='操作 / 江婧婕';
 const t={uid:'T1',id:'DZ-TEST-1',name:'测试团一',dep:'综合定制部',owner:'部门:综合定制部',category:'DZ',operatorA:'江婧婕',operatorB:'示例操作员',sales:'示例销售员',archiveKind:'single',departureDate:'2026-11-01',costConfirmed:true,costVersion:1,budget:8000,costItems:[{id:'C1',category:'交通',name:'交通',amount:5000},{id:'C2',category:'住宿',name:'酒店',amount:3000}],createdBy:activeRole};db.trips.push(t,{...structuredClone(t),uid:'T2',id:'DZ-TEST-2'});costMigrate(db);db.biz.initials.push({tripRef:'T1',cny:10000,amount:10000,version:1,currency:'CNY'},{tripRef:'T2',cny:5000,amount:5000,version:1,currency:'CNY'});
 const invoice={requestKey:'NEW1',company:COMPANY_OPTIONS[1],buyerType:'企业',title:'虚构测试抬头',taxId:'TEST-ONLY',invoiceType:'普通发票',sources:[{kind:'tour',ref:'T1',label:'测试团一',amount:'6000'},{kind:'tour',ref:'T2',label:'测试团二',amount:'4000'}],tickets:[{subject:'旅游费／团费',amount:'3000'},{subject:'代订酒店／住宿',amount:'7000'}]};
 const iid=v36InvoiceCreate(db,invoice),ir=db.v36.invoices.find(r=>r.id===iid);`);
eq('ir.total',10000);eq('ir.tickets.length',2);eq('ir.tickets[0].allocations.map(a=>a.cents)',[180000,120000]);eq('ir.tickets[1].allocations.map(a=>a.cents)',[420000,280000]);eq("v36InvoiceAvailable(db,v36InvoiceSources(db).find(s=>s.ref==='T1'))",4000);
eq('v36InvoiceCreate(db,invoice)',run('iid'));eq('db.v36.invoices.length',1);
throws("v36InvoiceCreate(db,{...invoice,requestKey:'DUPLIMIT'})",/额度/);
throws("v36InvoiceCreate(db,{...invoice,requestKey:'BADTAX',taxId:''})",/税号/);
throws("v36InvoiceCreate(db,{...invoice,requestKey:'BADSUM',sources:[{kind:'tour',ref:'T1',amount:'1'}]})",/合计/);
run(`const voidId=v36InvoiceVoid(db,{invoiceId:iid,ticketIds:[ir.tickets[1].id],reason:'测试部分原票作废'});`);
eq('db.v36.voids[0].amount',7000);eq("v36InvoiceAvailable(db,v36InvoiceSources(db).find(s=>s.ref==='T1'))",4000);
throws("v36InvoiceVoid(db,{invoiceId:iid,ticketIds:[ir.tickets[1].id],reason:'重复作废'})",/完整票/);
throws("v36InvoiceComplete(db,'void',voidId)",/仅财务/);
run("activeRole='财务 / 杜川黔'");throws("v36InvoiceComplete(db,'new',iid)",/作废/);
run("v36InvoiceComplete(db,'void',voidId)");eq("v36InvoiceAvailable(db,v36InvoiceSources(db).find(s=>s.ref==='T1'))",8200);eq("v36InvoiceAvailable(db,v36InvoiceSources(db).find(s=>s.ref==='T2'))",3800);
throws("v36InvoiceComplete(db,'void',voidId)",/已经处理/);run("v36InvoiceComplete(db,'new',iid)");eq('ir.status','completed');
// Cent rounding preserves every row and column, even for many tiny tickets.
run("const tiny=v36InvoiceMatrix([{kind:'tour',ref:'A',amount:'0.01'},{kind:'tour',ref:'B',amount:'0.02'}],[{amount:'0.01'},{amount:'0.01'},{amount:'0.01'}])");eq('tiny.map(t=>t.allocations.reduce((n,a)=>n+a.cents,0))',[1,1,1]);eq('tiny.reduce((n,t)=>n+t.allocations[0].cents,0)',1);
run("activeRole='销售 / 陌生用户'");eq('v36InvoiceSources(db).length',0);eq('v36InvoiceCanRead(db,ir)',false);throws("v36InvoiceCreate(db,{...invoice,requestKey:'UNAUTH'})",/授权/);
// Non-tour invoices link only confirmed eligible service receipts.
run(`activeRole='财务 / 杜川黔';db.receipts.push({id:'SERVICE',type:'项目／服务收款',status:'confirmed',amount:200,currency:'CNY',serviceItem:'咨询服务费',creator:'操作 / 江婧婕',date:'2026-11-02',allocations:[]},{id:'NOT-ELIGIBLE',type:'客户预存款',status:'confirmed',amount:200,currency:'CNY',allocations:[]});const serviceId=v36InvoiceCreate(db,{...invoice,requestKey:'SERVICE',buyerType:'个人',taxId:'',sources:[{kind:'receipt',ref:'SERVICE',amount:200}],tickets:[{subject:'旅游咨询／行程策划',amount:200}]});`);eq('db.v36.invoices.at(-1).sources[0].ref','SERVICE');eq("v36InvoiceSources(db).some(s=>s.ref==='NOT-ELIGIBLE')",false);
// Cash basis profit: receivable 10000, net receipt 5000, net payment 6000 => -1000.
run(`db.receipts.push({id:'CASH1',type:'客户团款',status:'confirmed',amount:5000,currency:'CNY',accountId:'bank',creator:'操作 / 江婧婕',date:'2026-11-03',version:1,allocations:[{ref:'T1',amount:5000}]});const a={id:'PAY-CNY',schema:3,paymentType:'业务付款',fee:'交通',tripUid:'T1',trip:t.id,creator:'操作 / 江婧婕',amount:6000,amountCNY:6000,currency:'CNY',stage:3,executionVersion:0,history:[],costIds:['C1','C2'],costAllocations:[{costId:'C1',amount:4000},{costId:'C2',amount:2000}]};db.apps.push(a);const p1=stExecute(db,a.id,{version:0,amount:6000,source:'bank',date:'2026-11-04',proof:{key:'test'},requestKey:'EXEC1'});`);
eq("stFunds(db,'T1').profit",-1000);eq("v36Receivable(db,'T1').pending",5000);eq('emGross(db,t).amount',-1000);match('v36ProfitPanel(t)',/-1,000\.00/);match('v36ProfitPanel(t)',/应收未收/);
throws("stExecute(db,a.id,{version:0,amount:6000,source:'bank',date:'2026-11-04',proof:{key:'test'},requestKey:'EXEC1'})",/刷新|重复/);
// No rate needed to submit or approve foreign payment; no CNY budget comparison at rate 1.
run(`activeRole='操作 / 江婧婕';const fx={...payNew(),type:'业务付款',fee:'住宿',tripRef:'T1',tripUid:'T1',owner:t.owner,note:'测试外币',amount:'1000',currency:'USD',demoBasis:true,payee:'虚构酒店',bank:'虚构银行',card:'TEST-ACCOUNT',channel:'公账收款',costIds:['C2'],costAllocations:[{costId:'C2',amount:1000}]};`);
eq('paymentValidate(fx,db)',[]);eq('checkPayment({...fx,paymentType:fx.type},db).limit',null);match('paymentPage.call(null)',/付款申请/);
run(`paymentDraft=fx`);assert.doesNotMatch(run('paymentPage()'),/核算汇率|折合人民币/);count++;
run(`const fa={...fx,id:'PAY-USD',schema:3,paymentType:fx.type,trip:t.id,creator:activeRole,amount:1000,amountCNY:7200,rate:7.2,executionVersion:0,history:[]};db.apps.push(fa);cfSnapshotRoute(db,fa);v36Init(db);`);eq('fa.amountCNY',null);eq('fa.rate',null);
for(const actor of ['主管 / 刘婷茹','财务 / 杜川黔','总经理 / 贺文峰'])run(`activeRole=${JSON.stringify(actor)};cfPaymentAct(db,fa.id,true,'测试',true,paymentRiskSignature(checkPayment(fa,db)))`);
eq('fa.stage',3);
run(`activeRole='财务 / 杜川黔';const bal=db.balance;const fpid=stExecute(db,fa.id,{version:0,amount:400,debitAmount:2840,actualCNY:9999,source:'bank',date:'2026-11-05',proof:{key:'proof'},requestKey:'FX1'});const fp=db.paymentReceipts.find(p=>p.id===fpid);`);
eq('bal-db.balance',2840);eq('fp.amount',2840);eq('fp.counterpartyAmount',400);eq('stRemaining(db,fa)',60000);eq('fp.costAllocationsCNY[0].cents',284000);eq("stFunds(db,'T1').profit",-3840);
run("db.receiptAccounts.push({id:'USD-ACCOUNT',name:'测试美元账户',currency:'USD',balance:5000,active:true});");throws("stExecute(db,fa.id,{version:1,amount:600,source:'USD-ACCOUNT',date:'2026-11-06',proof:{key:'test'},requestKey:'FX-NORATE'})",/人民币/);
run(`stExecute(db,fa.id,{version:1,amount:600,actualCNY:4260,source:'USD-ACCOUNT',date:'2026-11-06',proof:{key:'test'},requestKey:'FX2'});`);eq("rcBalance(db,'USD-ACCOUNT')",4400);eq('fa.stage',4);eq('stGross(db,fa)',100000);eq('stRemaining(db,fa)',0);eq("stFunds(db,'T1').profit",-8100);
throws("stExecute(db,fa.id,{version:2,amount:1,source:'bank',date:'2026-11-07',proof:{key:'test'},requestKey:'EXCEED'})",/额度/);
// Finance can adjust only original linked cost rows, with a reason and a conserved CNY total.
run(`const adj={...structuredClone(a),id:'ADJ',amount:100,currency:'CNY',stage:3,executionVersion:0};db.apps.push(adj);`);
throws("stExecute(db,'ADJ',{version:0,amount:100,source:'bank',date:'2026-11-08',proof:{key:'test'},requestKey:'ADJ1',costAllocationsCNY:[{costId:'C1',cents:5000},{costId:'OTHER',cents:5000}],allocationReason:'测试'})",/原关联/);
throws("stExecute(db,'ADJ',{version:0,amount:100,source:'bank',date:'2026-11-08',proof:{key:'test'},requestKey:'ADJ1',costAllocationsCNY:[{costId:'C1',cents:5000},{costId:'C2',cents:5000}]})",/原因/);
run("stExecute(db,'ADJ',{version:0,amount:100,source:'bank',date:'2026-11-08',proof:{key:'test'},requestKey:'ADJ1',costAllocationsCNY:[{costId:'C1',cents:5000},{costId:'C2',cents:5000}],allocationReason:'财务按实际用途更正'})");eq('db.paymentReceipts.at(-1).costAllocationsCNY.map(r=>r.cents)',[5000,5000]);
// Supervisor-approved profit drives one final commission even with a live book loss.
run(`activeRole='操作 / 江婧婕';stComplete(db,'T1');const sheet=db.commissionSheets.find(s=>s.tripRef==='T1');v35SheetAction(db,sheet.id,sheet.version,'operator',{receivable:10000,rows:sheet.actualRows,ack:true,reason:'测试'});activeRole='主管 / 刘婷茹';const finalRows=structuredClone(sheet.rows);finalRows[0].amount=250;finalRows[0].amountMode='manual';v35SheetAction(db,sheet.id,sheet.version,'supervisor',{base:2000,rows:finalRows,note:'按主管核定，销售提成调整为250'});`);
eq('sheet.rows.map(r=>r.amount)',[250,96,72]);eq('stTotal(sheet.rows)',418);eq('sheet.commissionBase',2000);eq('sheet.status','finance');
run(`activeRole='财务 / 杜川黔';v35SheetAction(db,sheet.id,sheet.version,'finance',{});`);eq('sheet.status','approved');eq("bzLatest(db,'T1').incomeCNY",5000);eq("bzLatest(db,'T1').costCNY",13200);eq("bzLatest(db,'T1').supervisorProfit",2000);eq("bzQuery(db,'2026-11').records.find(r=>r.tripRef==='T1').gross",-8200);
eq("bzConfigCan('rate')",false);run("cfSub='核算规则'");eq("cfTabs().includes('核算汇率')",false);match('tripForm()',/合同应收为0的原因/);
// Automatic paired internal transfer: one registration, two accounts, no external cash change.
run(`const tr={id:'TRANSFER',amount:300,amountCNY:300,currency:'CNY',stage:3,schema:3,paymentType:'资金往来',fee:'内部资金调拨',sourceAccount:'bank',targetAccount:'RC-BANK-2',executionVersion:0,history:[],creator:activeRole};db.apps.push(tr);const sumBefore=db.balance+rcBalance(db,'RC-BANK-2');stExecute(db,tr.id,{version:0,amount:300,source:'bank',date:'2026-11-09',proof:{key:'test'},requestKey:'TRANSFER1'});`);eq("db.balance+rcBalance(db,'RC-BANK-2')",run('sumBefore'));eq("db.receipts.filter(r=>r.automatic&&r.originalRef).length",1);eq("gmCashQuery(db,{from:'2026-11-01',to:'2026-11-30'}).internalNet",0);
console.log('v3.6 workflow checks passed:',count);
