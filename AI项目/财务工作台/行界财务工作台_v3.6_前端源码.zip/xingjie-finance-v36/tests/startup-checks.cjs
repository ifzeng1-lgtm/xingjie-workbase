const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const boot = fs.readFileSync('dist/boot.js', 'utf8');
const init = fs.readFileSync('dist/init.js', 'utf8');
function fixture({ populated = true } = {}) {
  const state = { removed: false, busy: true, frames: [], listeners: new Map(), message: '' };
  const root = { dataset: { appState: 'loading' } };
  const window = {
    addEventListener(name, fn) { state.listeners.set(name, fn); },
    removeEventListener(name) { state.listeners.delete(name); }
  };
  const nodes = {
    app: { children: populated ? [{}] : [] },
    'ui-header': {},
    'app-loading': { remove() { state.removed = true; } },
    'app-loading-message': { set textContent(value) { state.message = value; } }
  };
  const context = vm.createContext({
    window, document: {
      documentElement: root,
      body: { classList: { contains: value => value === 'ui-mode' } },
      getElementById: id => nodes[id] || null,
      addEventListener() {},
      querySelector: () => ({ removeAttribute() { state.busy = false; } })
    },
    requestAnimationFrame: fn => state.frames.push(fn),
    render() { state.rendered = true; }
  });
  vm.runInContext(boot, context);
  return { state, root, window, context, paint() { state.frames.splice(0).forEach(fn => fn()); } };
}
const a = fixture();
vm.runInContext(init, a.context);
assert.equal(a.state.rendered, true);
assert.equal(a.root.dataset.appState, 'loading');
assert.equal(a.state.removed, false);
a.window.XingjieBoot.ready();
assert.equal(a.state.frames.length, 1);
a.paint();
assert.equal(a.root.dataset.appState, 'ready');
assert.equal(a.state.removed, true);
assert.equal(a.state.busy, false);
assert.equal(a.state.listeners.has('error'), false);

const b = fixture();
b.window.XingjieBoot.ready();
b.state.listeners.get('error')({ target: { tagName: 'SCRIPT' } });
b.paint();
assert.equal(b.root.dataset.appState, 'error');
assert.equal(b.state.removed, false);
assert.match(b.state.message, /重新加载/);

const c = fixture({ populated: false });
vm.runInContext(init, c.context);
c.paint();
assert.equal(c.root.dataset.appState, 'error');
assert.equal(c.state.removed, false);

const d = fixture();
vm.runInContext('render = () => { throw Error("render failed"); }', d.context);
assert.throws(() => vm.runInContext(init, d.context), /render failed/);
assert.equal(d.root.dataset.appState, 'error');
assert.equal(d.state.removed, false);

const e = fixture();
e.state.listeners.get('error')({ target: { tagName: 'IMG' } });
vm.runInContext(init, e.context);
e.paint();
assert.equal(e.root.dataset.appState, 'ready');

const f = fixture();
f.state.listeners.get('unhandledrejection')({ reason: Error('startup failed') });
f.window.XingjieBoot.ready();
f.paint();
assert.equal(f.root.dataset.appState, 'error');
assert.equal(f.state.removed, false);

const index = fs.readFileSync('dist/index.html', 'utf8');
assert.match(index, /<html[^>]+data-app-state="loading"/);
assert.ok(index.indexOf('id="app-boot-styles"') < index.indexOf('<body>'));
const order = [...index.matchAll(/<script src="([^"?]+)(?:\?[^"]*)?"><\/script>/g)].map(m => m[1]);
assert.equal(order[0], 'boot.js');
assert.equal(order.at(-1), 'init.js');
assert.ok(order.indexOf('visual.js') < order.indexOf('init.js'));
assert.ok(order.indexOf('searchable-select.js') < order.indexOf('init.js'));
console.log('PASS startup: final UI before reveal, one startup frame, failed resource/render recovery, entry order');
